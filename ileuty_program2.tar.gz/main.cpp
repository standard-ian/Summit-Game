/*
 * Ian Leuty
 * ileuty@pdx.edu
 * 1/23/2025
 * CS302 Winter 2025
 * Program 2
 *
 ********************************************************************
 * main
 *********************************************************************
 */
#include "application.h"
using namespace std;


int main(void)
{
    srand(time(0));
    Game the_game;


    the_game.prompt();

    return 0;
}

